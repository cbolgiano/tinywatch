# The library files

The files in this directory provide library functionality to develop 
games fairly easily for the TinyScreen+. 

The current (19th oct 2016) state is fairly primitive as I've restarted from scratch. I'll port former features for optimizing drawing performance from
the old tinyduino playground project as it comes.